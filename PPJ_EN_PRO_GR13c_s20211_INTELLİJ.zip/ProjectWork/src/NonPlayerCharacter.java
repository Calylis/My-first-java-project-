import java.util.Scanner;

public class NonPlayerCharacter {
    public void NPC(){
        Scanner Npc = new Scanner(System.in);
        System.out.println("Hello stranger do you need my help ? ");
        String Answer = Npc.nextLine();
        if (Answer.equals("Yes")||Answer.equals("YES")||Answer.equals("Y")||Answer.equals("y")||Answer.equals("yes")) {
            System.out.println("What do you need ? ");
            Npc.nextLine();
            System.out.println("I dont know anything about your problem you should ask someone else\n There is a town in there...");
            System.out.println("Good bye");
            Player.PressEnter();

        }else System.out.println("Okay good Luck in out there");

        }
    }

