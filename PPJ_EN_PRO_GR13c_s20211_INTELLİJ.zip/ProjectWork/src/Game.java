import java.util.Scanner;
public class Game {
    private Map Map = new Map();
    public  void Start(){
        Scanner scanner = new Scanner(System.in);
        Player playerinfo = new Player();
        playerinfo.PlayerInfo();
        Map.GenerateMap();
        while (Player.Health > 0){
            Map.Map();
            System.out.println("Where do you want to go ? ");
            System.out.println("**************************");
            System.out.println("          NORTH           ");
            System.out.println("    WEST         EAST     ");
            System.out.println("          SOUTH           ");
            System.out.println("**************************");
            System.out.println("Health: "+ Player.Health +" Mana: "+ Player.Mana +" Experience: "+ Player.Experience +" Level: "+ Player.Level +" Money: "+ Player.Money +" AttackDamage: "+ Player.AttackDamage +" MagicDamage: "+playerinfo.MagicDamage+" ClassName "+playerinfo.ClassName);

            String Direction =scanner.nextLine();
            DirectionPerceive(Direction);
            System.out.println();
            playerinfo.CheckExperience();
            CheckWin();
        }
    }
    public void DirectionPerceive(String Direction){
        int ProX =Map.PlayerX, ProY =Map.PlayerY;
        if (Direction.equals("North")||Direction.equals("NORTH")||Direction.equals("north")||Direction.equals("N")||Direction.equals("n")){
            //Map.Move(Map.PlayerX--,Map.PlayerY);
            ProX--;
            Map.Move(ProX, ProY);
        }
        else if (Direction.equals("South")||Direction.equals("SOUTH")||Direction.equals("south")||Direction.equals("S")||Direction.equals("s")){
            //Map.Move(Map.PlayerX++,Map.PlayerY);
            ProX++;
            Map.Move(ProX, ProY);
        }
        else if (Direction.equals("East")||Direction.equals("EAST")||Direction.equals("east")||Direction.equals("E")||Direction.equals("e")){
            //Map.Move(Map.PlayerX,Map.PlayerY++);
            ProY++;
            Map.Move(ProX, ProY);
        }
        else if (Direction.equals("West")||Direction.equals("WEST")||Direction.equals("west")||Direction.equals("W")||Direction.equals("w")){
            //Map.Move(Map.PlayerX,Map.PlayerY--);
            ProY--;
            Map.Move(ProX, ProY);
        }
    }
    public void CheckWin(){
        if (Player.Level > 10 ){
            Player.Health = 0 ;
            System.out.println("*******************************************");
            System.out.println("WIN WIN WIN WIN WIN WIN WIN WIN WIN WIN WIN");
            System.out.println("*******************************************");
        }
    }
}
