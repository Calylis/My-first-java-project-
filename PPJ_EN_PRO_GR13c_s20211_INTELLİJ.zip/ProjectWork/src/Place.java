import java.util.Scanner;

public class Place {
    Scanner scanner = new Scanner(System.in);
public  void Hotel(){
    System.out.println("Welcome our hotel would you like to stay here ? ");
    String Answer = scanner.nextLine();
    if (Answer.equals("Yes")||Answer.equals("YES")||Answer.equals("Y")||Answer.equals("y")||Answer.equals("yes")) {
        Player.Health += 100;
        Player.Money -= 20;
        Player.Mana += 100;
        Player.Money -= 20;
        System.out.println("Your Money And Mana Restored" +
                "\nThank you for your stay with us");
    }else System.out.println("Okay good Luck in out there");
}
public void Market(){
    String Buy ="";
    while (!Buy.equals("Q")){
        System.out.println("What Do you want to buy ? If you want to exit \"Press Q to continue\"  ");
        System.out.println( "50 Health is 200€$" + "\n50 Mana is 250€$" + "\n20 AttackDamage is 500€$" + "\n25 MagicDamage is 600€$;");
        Buy = scanner.nextLine();
        if (Buy.equals("Health")||Buy.equals("HEALTH")||Buy.equals("H")||Buy.equals("health")||Buy.equals("h")){
            if (Player.Money >200){
                Player.Health +=50;
                Player.Money -=200;
                System.out.println("Thanks for buying");
            }else System.out.println("You dont have enough money...");
        }else if (Buy.equals("Mana")||Buy.equals("MANA")||Buy.equals("M")||Buy.equals("mana")||Buy.equals("m")){
            if (Player.Money >250) {
                Player.Mana += 50;
                Player.Money -= 250;
                System.out.println("Thanks for buying");
            }else System.out.println("You dont have enough money...");
        }else if (Buy.equals("AttackDamage")||Buy.equals("ATTACKDAMAGE")||Buy.equals("AD")||Buy.equals("A")||Buy.equals("attackdamage")||Buy.equals("ad")||Buy.equals("a")){
            if (Player.Money >500) {
                Player.AttackDamage += 20;
                Player.Money -= 500;
                System.out.println("Thanks for buying");
            }else System.out.println("You dont have enough money...");
        }else if (Buy.equals("MagicDamage")||Buy.equals("MAGICDAMAGE")||Buy.equals("MD")||Buy.equals("Magical")||Buy.equals("md")||Buy.equals("magicdamage")||Buy.equals("magic")){//Uzatılcak
            if (Player.Money >600) {
                Player.MagicDamage += 25;
                Player.Money -= 600;
                System.out.println("Thanks for buying");
            }else System.out.println("You dont have enough money...");
        }else if (!Buy.equals("Q"))
            System.out.println("I dont have what you want...");
        }
    System.out.println("Good bye");
    }
}

