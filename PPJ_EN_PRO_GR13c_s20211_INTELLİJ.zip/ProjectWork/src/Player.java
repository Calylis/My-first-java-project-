import java.util.Scanner;

public class Player {
    public String Name,ClassName;
    public static int Money,Health,Mana,Experience,Level,AttackDamage,MagicDamage;

    Scanner scanner = new Scanner(System.in);
   public void PlayerInfo(){
       System.out.println("Welcome to Diamond City \nDiamond City has been corrupted. We need a hero like yourself to get rid of. \nWe are glad to see you on our side");
       System.out.println("Could you tell us your Name");
       Name = scanner.nextLine();
       System.out.println("Greetings "+Name);
       System.out.println("Now You should chose your class");
       ClassSelect();
       System.out.println("So your class is "+ ClassName);//sectigi class a göre bir sesleniş
       System.out.println("This is Your Stats ");
       System.out.println("Health: "+Health+" Mana: "+Mana+" Experience: "+ Experience+" Level: "+Level+" Money: "+Money+" AttackDamage: "+AttackDamage+" MagicDamage: "+MagicDamage+" ClassName M"+ClassName);
       PressEnter();

   }
   public void Wizard(){
       Health = 150;
       Mana = 100;
       Experience = 0;
       Level = 1;
       Money =50;
       AttackDamage = 30;
       MagicDamage = 150;
       ClassName="Wizard";

   }
   public void Assassin(){
       Health = 150;
       Mana = 100;
       Experience = 0;
       Level = 1;
       Money =50;
       AttackDamage = 250;
       MagicDamage = 50;
       ClassName ="Assassin";
   }
   public void Knight(){
       Health = 400;
       Mana = 0;
       Experience = 0;
       Level = 1;
       Money =50;
       AttackDamage = 100;
       MagicDamage = 20;
       ClassName ="Knight";
   }
   public void Ranger(){
       Health = 150;
       Mana = 20;
       Experience = 0;
       Level = 1;
       Money =50;
       AttackDamage = 200;
       MagicDamage = 50;
       ClassName ="Ranger";
   }
   public void ClassSelect() {
       String Chose;
       int Dec = 0;
       while (Dec == 0) {

           System.out.println("1-WIZARD "+"2-ASSASSIN "+"3-KNIGHT "+"4-RANGER ");
           Chose = scanner.nextLine();
           if (Chose.equals("Wizard") || Chose.equals("WIZARD") || Chose.equals("W") || Chose.equals("w") || Chose.equals("wizard") || Chose.equals("1")) {
               Wizard();
               Dec++;
           } else if (Chose.equals("Assassin") || Chose.equals("ASSASSIN") || Chose.equals("assassin") || Chose.equals("A") || Chose.equals("a") || Chose.equals("2")) {
               Assassin();
               Dec++;
           } else if (Chose.equals("Knight") || Chose.equals("KNIGHT") || Chose.equals("knight") || Chose.equals("K") || Chose.equals("k") || Chose.equals("3")) {
               Knight();
               Dec++;
           } else if (Chose.equals("Ranger") || Chose.equals("ranger") || Chose.equals("RANGER") || Chose.equals("R") || Chose.equals("r") || Chose.equals("4")) {
               Ranger();
               Dec++;
           } else
               System.out.println("You Should Chose one of the classes");
       }
   }
    public static String PressEnter(){
        System.out.println("Press \"ENTER\" to continue...");
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();
    }
   public void LevelUp(){
       Level++;
       AttackDamage +=20;
       MagicDamage += 20;
       Health +=100;
   }
   public void CheckExperience(){
       if (Experience / 1000 >= Level )LevelUp();
   }
}
