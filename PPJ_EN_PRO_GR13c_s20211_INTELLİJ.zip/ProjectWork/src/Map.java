public class Map extends Player {
    private  NonPlayerCharacter Npc = new NonPlayerCharacter();
    private Enemy Monster = new Enemy();
    private Place place = new Place();
    public int PlayerX, PlayerY;
    public int[][] Map = new int[33][33];
    public String PlayerE ="\uD83D\uDC68 ",EnemyE = "\uD83D\uDC7D ", RoadE = "\uD83C\uDF32 ", GoldE = "\uD83D\uDCB0 ",NpcE ="\uD83D\uDE4B ", ShopE = "\uD83C\uDFEA ",HotelE ="\uD83C\uDFE8 ",WallE="\uD83C\uDF84 ",FootPrintE = "\uD83D\uDC63 ";

    public void Map() {
        for (int i = PlayerX - 2; i < PlayerX + 3; i++) {
            for (int j = PlayerY - 2 ; j < PlayerY + 3; j++) {
                if (Map[i][j] == 0) System.out.print(RoadE);
                else if (Map[i][j] == 1) System.out.print(PlayerE);          // 👨
                else if (Map[i][j] == 2) System.out.print(EnemyE);          //  👽
                else if (Map[i][j] == 3) System.out.print(GoldE);          //   🌲
                else if (Map[i][j] == 4) System.out.print(NpcE);          //    💰
                else if (Map[i][j] == 5) System.out.print(ShopE);        //     🙋
                else if (Map[i][j] == 6) System.out.print(HotelE);      //      🏨
                else if (Map[i][j] == 7) System.out.print(WallE);      //       🎄
                else if (Map[i][j] == 9) System.out.print(FootPrintE);//        👣
            }
            System.out.println();
        }
    }
    public void GenerateMap() {
        PlayerX = 16;
        PlayerY = 16;
        Map[PlayerX][PlayerY] = 1;
        GenerateEnemy();
        GenerateGold();
        GenerateNPC();
        GenerateShop();
        GenerateHotel();
        GenerateWall();
    }
    public void GenerateEnemy() {
        int i;
        for (i = 0; i < 100; ) {
            int x = (int) (Math.random() * 33);
            int y = (int) (Math.random() * 33);
            if (Map[x][y] == 0) {
                i++;
                Map[x][y] = 2;
            }
        }
    }
    public void GenerateGold() {
        int i;
        for (i = 0; i < 80; ) {
            int x = (int) (Math.random() * 33);
            int y = (int) (Math.random() * 33);
            if (Map[x][y] == 0) {
                i++;
                Map[x][y] = 3;
            }
        }
    }
    public void GenerateNPC() {
        int i;
        for (i = 0; i < 50; ) {
            int x = (int) (Math.random() * 33);
            int y = (int) (Math.random() * 33);
            if (Map[x][y] == 0) {
                i++;
                Map[x][y] = 4;
            }
        }
    }
    public void GenerateShop() {
        int i;
        for (i = 0; i < 50; ) {
            int x = (int) (Math.random() * 33);
            int y = (int) (Math.random() * 33);
            if (Map[x][y] == 0) {
                i++;
                Map[x][y] = 5;
            }
        }
    }
    public void GenerateHotel() {
        int i;
        for (i = 0; i < 50; ) {
            int x = (int) (Math.random() * 33);
            int y = (int) (Math.random() * 33);
            if (Map[x][y] == 0) {
                i++;
                Map[x][y] = 6;
            }
        }
    }
    public void Move(int MoveX, int MoveY) {
        int[] Result = new int[2];
        if (Map[MoveX][MoveY] == 0) {
            System.out.println("Please keep walking there is nothing here");
            Go(MoveX,MoveY);
        } else if (Map[MoveX][MoveY] == 2) {
           Result = Monster.Battle();
           Player.Experience += Result[0];
           Player.Money += Result[1];
            Go(MoveX,MoveY);
        } else if (Map[MoveX][MoveY] == 3) {
            System.out.println("+100€$");
            Player.Money += 100;
            Go(MoveX,MoveY);
        } else if (Map[MoveX][MoveY] == 4) {
            Npc.NPC();
            Go(MoveX,MoveY);
        } else if (Map[MoveX][MoveY] == 5) {
            place.Market();
            Go(MoveX,MoveY);
        } else if (Map[MoveX][MoveY] == 6) {
            place.Hotel();
            Go(MoveX,MoveY);
        }else if (Map[MoveX][MoveY] == 7){
            System.out.println("There is an invisible wall you can't go there...");
        }else Go(MoveX,MoveY);
    }
    public void GenerateWall (){
        for (int i = 5; i <= 28; i++) {
            Map[i][5] =7;
            Map[5][i] =7;
        }for (int i = 28; i >= 5; i--) {
            Map[i][28] =7;
            Map[28][i] =7;
        }
    }
    public void Go(int MoveX,int MoveY){
        Map[PlayerX][PlayerY] =9;
        PlayerX = MoveX;
        PlayerY = MoveY;
        Map[PlayerX][PlayerY] = 1;
        Experience += 100;
    }
}



