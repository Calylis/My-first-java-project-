public class Enemy extends Player {
    public int Health,AttackDamage,MagicDamage,Experience,Money;

    public void Monster() {
        this.Health = 300 + (Player.Level*100);
        this.AttackDamage = 20 +(Player.Level*10);
        this.Experience = 100 + (Player.Level * 100);
        this.Money = 100 + (Player.Level * 50);
    }
    public int[] Battle (){
        int[] Result = {Experience,Money};
        Monster();
        boolean Continue = true;
        int TrueAttackDamage = Player.AttackDamage+Player.MagicDamage;
        while (Continue){
            System.out.println("Monster hit you "+this.AttackDamage);
            Player.Health -= this.AttackDamage;
            System.out.println("You hit "+TrueAttackDamage);
            this.Health -= TrueAttackDamage;
            if (this.Health < 0 && Player.Health >0){
                System.out.println("You have killed The Monster \nYou have gain "+this.Experience+" Experience "+this.Money+" Money.");
                Continue = false;
            }else if (Player.Health < 0){
                System.out.println("You have died");
                System.out.println("You Lost The Game...");
                Continue = false;
            }
        }
        System.out.println("Health: "+ Player.Health +" Mana: "+ Player.Mana +" Experience: "+ Player.Experience +" Level: "+ Player.Level +" Money: "+ Player.Money);
        Player.PressEnter();
        return Result;
    }
}
